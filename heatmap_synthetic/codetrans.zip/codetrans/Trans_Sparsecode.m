function X=Trans_Sparsecode(W,Y,s)
Sparse_code_ts = W*Y ;
X = zeros(size(Sparse_code_ts));
for ci = 1:1:size(Sparse_code_ts,2)
     Sparse_code_ts_c= Sparse_code_ts(:,ci);
     tmp_l3 = sort(abs(Sparse_code_ts_c),'descend');
     tmp_l3 = tmp_l3(s);
     Sparse_code_ts_c(abs(Sparse_code_ts_c)<tmp_l3)=0;
     X(:,ci)=Sparse_code_ts_c;
end
     