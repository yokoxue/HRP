function Wnew=Trans_Dic(Wlas,Y,X,lambda,mu,eta,Iter)
W = Wlas;
conv=[];
for i = 1:1:Iter
Grad = 2*W*Y*Y.'-2*X*Y.'-lambda*inv(W).'+mu*2*W;
W = W-eta*Grad;
%obj  = Trans_Learn_Obj(Y,W,X,lambda,mu);
%conv =[conv obj];
end
Wnew =W;


