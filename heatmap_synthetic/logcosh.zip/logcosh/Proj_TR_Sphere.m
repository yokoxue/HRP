% TR_sphere.m: trust region method over the sphere for recovering a single
% sparse vector.
% Recover one sparsest row of Y by solving:
%  min_q  h_mu(q' * Y),  s.t.  ||q|| =1.

function q = Proj_TR_Sphere( Y, mu, q_init,P ,D0)
Yt = P'*Y;
[n,~] = size(Yt);
% initalize q
if nargin > 2,
    q = q_init;
else
    q = randn(n,1);% random initialization
    q = q / norm(q);
end

%% Parameter Settings

tol = 1e-6;% stopping criteria for the gradient
MaxIter = 200;% max iteration
Delta = 0.1;% inital trust region size
Delta_max = 1;% maximum trust region size
Delta_min = eps;% minimum trust region size

% parameters for adjusting trust region size
eta_s = 0.1;
eta_vs = 0.9;
gamma_i = 2;
gamma_d = 1/2;


%% Main Iteration
for iter = 1:MaxIter
    U = null(q'); % basis of the tangent space T_q = { v| v'*q =0}
    [f,g,H] =Proj_l1_exp_approx(Y,q,mu,true,P); % evaluate the function, gradient and hessian at q
    
    %solve TR-subprolbem
    A = U' * H * U - q' * g * eye(n-1); % hessian in the tangent space T_q
    b = U' * g; % gradient in the tangent space T_q
    [xi,opt] = Solve_TR_Subproblem(A,b,Delta); % optimal direction xi in the tangent space T_q
    
    t = norm(xi);
    q_hat = q * cos(t) + (U*xi/t) * sin(t);% retraction back to the sphere by exponential map
    
    % evaluate the trust region ratio: rho
    f_new = Proj_l1_exp_approx(Y,q_hat,mu,false,P);
    f_hat = f + b' * xi + (1/2) * xi' * A * xi;
    rho = (f - f_new)/(f-f_hat);
    
    % update iterate q and trust-region size Delta
    flag = 0;
    if rho>eta_vs
        q = q_hat; flag = 1;
        Delta = min(gamma_i*Delta,Delta_max);
    elseif rho>eta_s
        q = q_hat; flag = 1;
    else
        Delta = max(gamma_d*Delta,Delta_min);
    end
    q_rot = D0' *P*q;  
    err= abs(max(abs(q_rot))-1);% should be 1-sparse if one dictionary element is found
    % early stopping if recovered
    if err <= mu/2
     
        %record_basis(ind) = 1;  % recovery up to sign
        break
    end
    
    fprintf('Iter = %d, Obj = %f, Err = %f, TR Size = %f, Step = %f, rho = %f \n',iter,f,err, Delta,t,rho);
    
    % early termination - this is sufficient for recovery
    
    
    if (flag ==1&&abs((f_new - f)/t)<tol)
        break;
    end
    
end

end
