% evaluate the value f, gradient g and hessian H 
% for the function h_mu(q'*Y) 
function [f,g,H] = Proj_l1_exp_approx(Y,q,mu,flag,P)
    Yt = P'*Y;
	z = q'*Yt;
	t = z/mu;
	ind = abs(t)>50; % to prevent overflow
	n = size(Yt,1);

	f_each_1 = mu * log( cosh(t(~ind)) );
	f_each_2 = abs(z(ind)) - mu*log(2);
	f = sum(f_each_1)+sum(f_each_2); %function value

	if(flag == true)    
		g_each =  tanh(t);
		H_each = (1/mu) * (1-g_each.^2);    
		g = Yt * g_each';% gradient 
		H = (Yt.* repmat(H_each, n, 1))*Yt'; %hessian H = Y * diag(H_each) * Y
	end

end
