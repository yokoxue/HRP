%% Trans_learn
K=20;
N=K;
M = 10000;
Theta = 0.2;
%% Gen sparse code
B = rand(K,M);
B(B>Theta) = 0;
B(B>0) = 1;
G = randn(K,M);
X0 = B.*G;
Dini = randn(N);
[Q,~] = qr(Dini);
D0 = Q;
%% Gen Measure
Y0 = D0*X0;
%% add noise
raw_power = norm(Y0,'fro')^2/numel(Y0);

Y = Y0;
%initial
% [dic_size, sample_size] = size(Y);
% [A0,~] = qr(randn(dic_size));
% A0 = A0(:,1:dic_size);
W =eye(N);
s= Theta*N;
lambda = 0.5;
mu = 0.25;
eta = 10^-4;Tr_Iter=60;
Iter = 1000;
conv = [];
for i = 1:1:Iter
    X=Trans_Sparsecode(W,Y,s);
    W=Trans_Dic(W,Y,X,lambda,mu,eta,Tr_Iter);
    obj  = Trans_Learn_Obj(Y,W,X,lambda,mu);
    conv =[conv obj];
end
Dic_out = W;
Code_out = X;
A_Trans_Learn=De_permutation(Dic_out,D0);
Error_Trans_Learn_inst = norm( A_Trans_Learn - D0,'fro')^2/norm(D0,'fro')^2;
fprintf(' DL Trans done!\n');