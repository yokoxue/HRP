function Obj=Trans_Learn_Obj(Y,W,X,lambda,mu)
Obj = norm(W*Y-X,'fro')^2-lambda*logdet(W)+mu*norm(W,'fro')^2;
