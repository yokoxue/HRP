function [UNTF]= Gen_UNTF(A)
T_MAX = 1000;
Min_ERROR = 1e-15;
t=0;
error = 2;
UNTF = A;
while(t<T_MAX&& error>Min_ERROR)
    [U,~,V] = svd(UNTF,'econ');
    Z= U*V';
    UNTF2 = normc(Z);
    t = t+1;
    error = norm(UNTF2-UNTF,'fro')^2;
    UNTF=UNTF2;
end
    
    