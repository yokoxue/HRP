N = 10;
K = 10;
M = 200;
Theta = 0.4;
Theta_corr = 0;
SNR = inf;
lp = 3; %%lp order
% SNR = 0;%norm(Y0,'fro')/sqrt(n*m)*sqrt(0);
% Theta_corr = 0.2;

Test_num = 10;


Error_Spams = 0;
Time_Spams  = 0;

for trial_ind = 1:Test_num
    
    %% Gen dict
    %rng(2019)
    Dini = randn(N);
    [Q,~] = qr(Dini);
    D0 = Q(:,1:K);
    %% Gen sparse code
    B = rand(N,M);
    B(B>Theta) = 0;
    B(B>0) = 1;
    G = randn(N,M);
    X0 = B.*G;
    %% Gen Measure
    Y0 = D0*X0;
    
    %% add noise
    raw_power = norm(Y0,'fro')^2/numel(Y0);
    noi_var = raw_power/(10^(SNR/10));
    Y = Y0 + (eps+noi_var)*randn(N,M);
    
    
    
    
    %% DL
    [dic_size, sample_size] = size(Y);
    [A0,~] = qr(randn(dic_size));
    A0 = A0(:,1:dic_size);
    param.D =  A0;
    param.lambda=0.15;
    param.numThreads=-1; % number of threads
    param.batchsize=400;
    param.verbose=false;
    param.modeD=0;

    param.iter=1000;  % let us see what happens after 1000 iterations.
    tic
    A_Spams = mexTrainDL(Y,param);
    toc_Spams=toc;
    p_mat_Spams = A_Spams' *  D0;
    sign_p_Spams  = sign (p_mat_Spams );
    [~,flagone_Spams ] = max (abs(p_mat_Spams ));
    p_mat_0_Spams  = eye(size(p_mat_Spams ));
    p_mat_0_Spams  = p_mat_0_Spams  (:,flagone_Spams );
    p_mat_1_Spams  = p_mat_0_Spams .*sign_p_Spams ;
    A_Spams = A_Spams  * p_mat_1_Spams ;
    %error
    Error_Spams_inst= norm( A_Spams  - D0,'fro')^2/norm(D0,'fro')^2;
     %% Display
    fprintf('trail %d\n',  trial_ind );
    fprintf('SNR: %d ,  N: %d, K: %d, M: %d, Rho: %d\n', SNR, N,K,M,Theta);
   
    fprintf(' Spams  error : %g, time %e\n',  Error_Spams_inst , toc_Spams );

 %% cal metric
    Error_Spams = Error_Spams  + Error_Spams_inst/Test_num;
    
    
    Time_Spams  = Time_Spams + toc_Spams /Test_num;
   

end

